for calculo in range(2,101,2):
    print(calculo)
print('Fim')
    
#Exercício 2

for n in range(1,51,1):
    for n in range(52,101,2):
        print(calculo)
        print('Fim')

    
