v1= float (input("Digite a Hora:"))
v2= float (input("Digite os minutos:"))
print("Os minutos são:", (v1+v2))

n1= float (input("Qual sua idade em anos?:"))
n2=float (input("Qual sua idade em meses?:"))
n3=float (input("Qual sua idade em dias?:"))
print("Sua idade em dias são:", (n1+n2))

prestacao=float (input("Digite o valor da prestação em atraso:"))

multa=float (input("Digite o valor da multa:"))
qntdatraso= float (input("Digite o valor da quantidade de atraso:"))
print("O resultado é:", (prestacao+(multa/100)*qntdatraso))

a= float (input("Digite seu metro:"))
b= float (input("Digite seu peso:"))
print("O resultado é:", a/b**2)

c= float (input("Digite o valor do lado do retângulo A e B:"))
d= float (input("Digite o valor do lado do retângulo C e D:"))
print ("O perímetro é", (2*a+2*b))
print ("A área é :", a*b)

nome = input ("Digite seu nome;")
print("Boa Noite", nome, "!!")
profaluno = input ("Digite sua profissão:")
print (profaluno)
idade = input ("Digite a sua idade:")
esporte = input ("Digite seu esporte favorito:")
print (esporte)
signo = input ("Digite seu signo:")
print (signo)
cor = input ("Digite sua cor favorita:")
print (cor)
      
