cont = 0
media = 0
while cont<=10:
    x = float(input('entre com um num:'))
    media = media + x
    cont = cont + 1
else:
    print(media)
