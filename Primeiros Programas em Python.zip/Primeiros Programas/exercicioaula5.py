compra = float(input("Digite o valor da compra:"))
if compra >=200:
    cvalor= compra*0.20
    
    print("Vôce possui desconto!:)", cvalor-compra)
else:
    print("Você não possui desconto!:(", 200-compra)

luz = float(input("Digite o valor da conta de Luz:"))
internet = float (input("Digite o valor da conta de Internet:"))
facul = float(input("Digite o valor da mensalidade da Faculdade/Universidade:"))
salario = float(input("Digite o valor do seu Salário:"))

contas=luz+internet+facul
salario-contas

if contas>salario:
    print("Seu salário é insuficiente para o pagamento das contas!:(")
    
else:
    print("Seu salário é suficiente para o pagamento das contas!:)")
    print("Sobrou:", salario-contas)
    
