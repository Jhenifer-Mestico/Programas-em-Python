dias_semana = list()
volChuva = list()
media = 0

for i in range(10):
    s = input("Digite um dia da semana: ")
    v = float(input("Digite o volume de chuva correspondente a 10 dias: "))
    dias_semana.append (s)
    volChuva.append (v)

soma_quarta = 0
valor_Quarta = 0

for i in range(0,len(dias_semana)):
    if dias_semana[i] == 'quarta':
        soma_quarta = soma_quarta + volChuva[i]
        valor_Quarta = valor_Quarta + 1
        
        if valor_Quarta > 0:
            media = soma_quarta/valor_Quarta
print("O volume de chuva na(s) quarta(s) feira(s) será: ", media)


soma = 0
for valor in volChuva:
    soma = soma + valor
print(" O volume máximo de chuva é:", soma)
            
