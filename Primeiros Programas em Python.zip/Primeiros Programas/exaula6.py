n1 = 0
n2 = 0
resultado = 0
operacao = ""

n1 = int(input("Digite o primeiro número:"))
operacao = input ("Digite a operação:")
n2 = int(input("Digite o segundo número:"))

if operacao == "+":
   print ("resultado:", (n1 + n2))
elif operacao == "-":
   print ("resultado:", (n1 - n2))
elif operacao == "/":
   print ("resultado:", (n1 / n2))
elif operacao == "*":
   print ("resultado", (n1 * n2))
else:

    print(str(n1) + " " + str(operacao) + " " + str (n2) + " = " + str (resultado))

    #exercício 2

    a= float (input("Digite seu peso:"))
    b= float (input("Digite seu altura"))
    imc = (a/b*2)
    if imc >=20 and imc <25:
        print ("Peso Normal")
    elif imc and imc <20:
        print ("Abaixo do peso")
    elif imc >=25 and imc <30:
        print ("Sobrepeso")
    elif imc >=30 and imc <40:
        print ("Obeso")
    elif imc >=40:
        print ("Obeso Mórbido")
    

        
          
